import{_ as m}from"./EditOnLink.vue.33f97b75.js";import"./entry.909583b9.js";export{m as default};
