import{k as e,b as _,c as r}from"./entry.909583b9.js";const t={};function c(o,s){return _(),r("hr")}const a=e(t,[["render",c],["__scopeId","data-v-89dedb08"]]);export{a as default};
