import{f as n}from"./node.676c5e99.js";import{a1 as i}from"./entry.909583b9.js";const e=(t,r,f,...a)=>t[r]?i({...t,[r]:()=>n(t[r](),f==null?void 0:f.unwrap)},r,f,...a):i(t,r,f,...a);export{e as r};
