import{k as t,b as n,c as o,a1 as c}from"./entry.909583b9.js";const r={};function s(e,a){return n(),o("tbody",null,[c(e.$slots,"default")])}const l=t(r,[["render",s]]);export{l as default};
